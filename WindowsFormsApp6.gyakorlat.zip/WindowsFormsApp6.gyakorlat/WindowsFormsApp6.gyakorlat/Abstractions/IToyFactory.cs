﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp6.gyakorlat.Abstractions
{
    public interface IToyFactory
    {
        Toy CreateNew();
    }
}
